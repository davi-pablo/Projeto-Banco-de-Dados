# UNIVERSI TOUR - Sistema de Viagens

## Instalação Rápida

1. **Extraia este arquivo ZIP**
2. **Execute:** `python instalar_projeto.py`
3. **Siga as instruções** na tela

## Pré-requisitos

- Python 3.8+ instalado
- MySQL Server instalado e rodando

## Execução

Após instalação:
- **Windows:** Duplo clique em `EXECUTAR.bat`
- **Linux/Mac:** `python rodar_tudo.py`

## URLs do Sistema

- Site: http://localhost:8080/html.html
- Admin: http://localhost:8080/admin.html
- API: http://127.0.0.1:5000/api/destinos

## Suporte

Consulte `GUIA_INSTALACAO.md` para instruções detalhadas.
