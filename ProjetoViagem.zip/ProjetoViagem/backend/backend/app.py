from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
import pymysql

app = Flask(__name__)
CORS(app)


MYSQL_HOST = 'localhost'
MYSQL_PORT = '3306'
MYSQL_USER = 'root' 
MYSQL_PASSWORD = '1234' 
MYSQL_DATABASE = 'universi_tour' 

# URL de conexão MySQL
MYSQL_URL = f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE}'

app.config['SQLALCHEMY_DATABASE_URI'] = MYSQL_URL
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
    'connect_args': {'charset': 'utf8mb4'}
}

db = SQLAlchemy(app)

# Modelos do banco de dados
class Destino(db.Model):
    __tablename__ = 'destino'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text, nullable=False)
    imagem = db.Column(db.String(200), nullable=False)
    distancia = db.Column(db.String(50), nullable=False)
    preco = db.Column(db.String(20), nullable=False)
    preco_numerico = db.Column(db.DECIMAL(10, 2), nullable=False)
    ativo = db.Column(db.Boolean, default=True)
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'descricao': self.descricao,
            'imagem': self.imagem,
            'distancia': self.distancia,
            'preco': self.preco,
            'preco_numerico': self.preco_numerico,
            'ativo': self.ativo,
            'data_criacao': self.data_criacao.isoformat()
        }

class Usuario(db.Model):
    __tablename__ = 'usuario'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    telefone = db.Column(db.String(20))
    data_cadastro = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamento com reservas
    reservas = db.relationship('Reserva', backref='usuario', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'email': self.email,
            'telefone': self.telefone,
            'data_cadastro': self.data_cadastro.isoformat()
        }

class Reserva(db.Model):
    __tablename__ = 'reserva'
    
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)
    destino_id = db.Column(db.Integer, db.ForeignKey('destino.id'), nullable=False)
    data_viagem = db.Column(db.Date, nullable=False)
    data_retorno = db.Column(db.Date, nullable=False)
    num_pessoas = db.Column(db.Integer, nullable=False)
    valor_total = db.Column(db.DECIMAL(10, 2), nullable=False)
    status = db.Column(db.String(20), default='pendente')  # pendente, confirmada, cancelada
    observacoes = db.Column(db.Text)
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    destino = db.relationship('Destino', backref='reservas')

    def to_dict(self):
        return {
            'id': self.id,
            'usuario_id': self.usuario_id,
            'destino_id': self.destino_id,
            'destino_nome': self.destino.nome if self.destino else None,
            'data_viagem': self.data_viagem.isoformat(),
            'data_retorno': self.data_retorno.isoformat(),
            'num_pessoas': self.num_pessoas,
            'valor_total': self.valor_total,
            'status': self.status,
            'observacoes': self.observacoes,
            'data_criacao': self.data_criacao.isoformat()
        }

class Contato(db.Model):
    __tablename__ = 'contato'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    mensagem = db.Column(db.Text, nullable=False)
    data_envio = db.Column(db.DateTime, default=datetime.utcnow)
    respondido = db.Column(db.Boolean, default=False)

    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'email': self.email,
            'mensagem': self.mensagem,
            'data_envio': self.data_envio.isoformat(),
            'respondido': self.respondido
        }

# Criar tabelas do banco de dados
with app.app_context():
    try:
        db.create_all()
        print("Tabelas criadas com sucesso!")
        
        # Inserir dados iniciais se não existirem
        if Destino.query.count() == 0:
            print("Inserindo dados iniciais...")
            destinos_iniciais = [
                Destino(
                    nome="Rio de Janeiro",
                    descricao="A cidade carioca, famosa por suas praias e seus pontos turísticos.",
                    imagem="Imagens/rio.jpg",
                    distancia="100-500",
                    preco="medio",
                    preco_numerico=800.00
                ),
                Destino(
                    nome="Salvador",
                    descricao="A cidade calorosa, um lugar de tradição e cultura.",
                    imagem="Imagens/salvador.jpg",
                    distancia="500-1000",
                    preco="alto",
                    preco_numerico=1200.00
                ),
                Destino(
                    nome="Recife",
                    descricao="A cidade maravilhosa, com praias paradisíacas e cultura vibrante.",
                    imagem="Imagens/recife.jpg",
                    distancia="0-100",
                    preco="baixo",
                    preco_numerico=500.00
                )
            ]
            
            for destino in destinos_iniciais:
                db.session.add(destino)
            
            db.session.commit()
            print("Dados iniciais inseridos com sucesso!")
        else:
            print("Dados iniciais já existem no banco.")
            
    except Exception as e:
        print(f"Erro ao criar tabelas ou inserir dados: {e}")
        db.session.rollback()

# ==================== ROTAS DA API ====================

# ROTAS PARA DESTINOS
@app.route('/api/destinos')
def get_destinos():
    """Retorna todos os destinos ativos"""
    destinos = Destino.query.filter_by(ativo=True).all()
    return jsonify([destino.to_dict() for destino in destinos])

@app.route('/api/destinos/<int:destino_id>')
def get_destino(destino_id):
    """Retorna um destino específico"""
    destino = Destino.query.get_or_404(destino_id)
    return jsonify(destino.to_dict())

@app.route('/api/destinos', methods=['POST'])
def create_destino():
    """Cria um novo destino"""
    data = request.get_json()
    
    destino = Destino(
        nome=data['nome'],
        descricao=data['descricao'],
        imagem=data['imagem'],
        distancia=data['distancia'],
        preco=data['preco'],
        preco_numerico=data['preco_numerico']
    )
    
    db.session.add(destino)
    db.session.commit()
    
    return jsonify(destino.to_dict()), 201

@app.route('/api/destinos/<int:destino_id>', methods=['PUT'])
def update_destino(destino_id):
    """Atualiza um destino"""
    destino = Destino.query.get_or_404(destino_id)
    data = request.get_json()
    
    destino.nome = data.get('nome', destino.nome)
    destino.descricao = data.get('descricao', destino.descricao)
    destino.imagem = data.get('imagem', destino.imagem)
    destino.distancia = data.get('distancia', destino.distancia)
    destino.preco = data.get('preco', destino.preco)
    destino.preco_numerico = data.get('preco_numerico', destino.preco_numerico)
    
    db.session.commit()
    return jsonify(destino.to_dict())

@app.route('/api/destinos/<int:destino_id>', methods=['DELETE'])
def delete_destino(destino_id):
    """Remove um destino (soft delete)"""
    destino = Destino.query.get_or_404(destino_id)
    destino.ativo = False
    db.session.commit()
    return jsonify({'message': 'Destino removido com sucesso'})

# ROTAS PARA USUÁRIOS
@app.route('/api/usuarios')
def get_usuarios():
    """Retorna todos os usuários"""
    usuarios = Usuario.query.all()
    return jsonify([usuario.to_dict() for usuario in usuarios])

@app.route('/api/usuarios/<int:usuario_id>')
def get_usuario(usuario_id):
    """Retorna um usuário específico"""
    usuario = Usuario.query.get_or_404(usuario_id)
    return jsonify(usuario.to_dict())

@app.route('/api/usuarios', methods=['POST'])
def create_usuario():
    """Cria um novo usuário"""
    data = request.get_json()
    
    # Verificar se email já existe
    if Usuario.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Email já cadastrado'}), 400
    
    usuario = Usuario(
        nome=data['nome'],
        email=data['email'],
        telefone=data.get('telefone')
    )
    
    db.session.add(usuario)
    db.session.commit()
    
    return jsonify(usuario.to_dict()), 201

# ROTAS PARA RESERVAS
@app.route('/api/reservas')
def get_reservas():
    """Retorna todas as reservas"""
    reservas = Reserva.query.all()
    return jsonify([reserva.to_dict() for reserva in reservas])

@app.route('/api/reservas/<int:reserva_id>')
def get_reserva(reserva_id):
    """Retorna uma reserva específica"""
    reserva = Reserva.query.get_or_404(reserva_id)
    return jsonify(reserva.to_dict())

@app.route('/api/reservas', methods=['POST'])
def create_reserva():
    """Cria uma nova reserva"""
    data = request.get_json()
    
    # Verificar se usuário existe
    usuario = Usuario.query.get(data['usuario_id'])
    if not usuario:
        return jsonify({'error': 'Usuário não encontrado'}), 400
    
    # Verificar se destino existe
    destino = Destino.query.get(data['destino_id'])
    if not destino:
        return jsonify({'error': 'Destino não encontrado'}), 400
    
    # Calcular valor total
    valor_total = destino.preco_numerico * data['num_pessoas']
    
    reserva = Reserva(
        usuario_id=data['usuario_id'],
        destino_id=data['destino_id'],
        data_viagem=datetime.strptime(data['data_viagem'], '%Y-%m-%d').date(),
        data_retorno=datetime.strptime(data['data_retorno'], '%Y-%m-%d').date(),
        num_pessoas=data['num_pessoas'],
        valor_total=valor_total,
        observacoes=data.get('observacoes')
    )
    
    db.session.add(reserva)
    db.session.commit()
    
    return jsonify(reserva.to_dict()), 201

@app.route('/api/reservas/<int:reserva_id>/status', methods=['PUT'])
def update_reserva_status(reserva_id):
    """Atualiza o status de uma reserva"""
    reserva = Reserva.query.get_or_404(reserva_id)
    data = request.get_json()
    
    reserva.status = data.get('status', reserva.status)
    db.session.commit()
    
    return jsonify(reserva.to_dict())

# ROTAS PARA CONTATOS
@app.route('/api/contatos')
def get_contatos():
    """Retorna todos os contatos"""
    contatos = Contato.query.order_by(Contato.data_envio.desc()).all()
    return jsonify([contato.to_dict() for contato in contatos])

@app.route('/api/contatos', methods=['POST'])
def create_contato():
    """Cria um novo contato"""
    data = request.get_json()
    
    contato = Contato(
        nome=data['nome'],
        email=data['email'],
        mensagem=data['mensagem']
    )
    
    db.session.add(contato)
    db.session.commit()
    
    return jsonify(contato.to_dict()), 201

@app.route('/api/contatos/<int:contato_id>/respondido', methods=['PUT'])
def marcar_contato_respondido(contato_id):
    """Marca um contato como respondido"""
    contato = Contato.query.get_or_404(contato_id)
    contato.respondido = True
    db.session.commit()
    
    return jsonify(contato.to_dict())

# ROTA PARA ESTATÍSTICAS
@app.route('/api/estatisticas')
def get_estatisticas():
    """Retorna estatísticas do sistema"""
    total_destinos = Destino.query.filter_by(ativo=True).count()
    total_usuarios = Usuario.query.count()
    total_reservas = Reserva.query.count()
    total_contatos = Contato.query.count()
    contatos_nao_respondidos = Contato.query.filter_by(respondido=False).count()
    
    return jsonify({
        'total_destinos': total_destinos,
        'total_usuarios': total_usuarios,
        'total_reservas': total_reservas,
        'total_contatos': total_contatos,
        'contatos_nao_respondidos': contatos_nao_respondidos
    })

# ROTA PARA BUSCA DE DESTINOS
@app.route('/api/destinos/buscar')
def buscar_destinos():
    """Busca destinos por filtros"""
    nome = request.args.get('nome', '')
    distancia = request.args.get('distancia', '')
    preco = request.args.get('preco', '')
    
    query = Destino.query.filter_by(ativo=True)
    
    if nome:
        query = query.filter(Destino.nome.contains(nome))
    if distancia:
        query = query.filter(Destino.distancia == distancia)
    if preco:
        query = query.filter(Destino.preco == preco)
    
    destinos = query.all()
    return jsonify([destino.to_dict() for destino in destinos])

if __name__ == '__main__':
    app.run(debug=True)
