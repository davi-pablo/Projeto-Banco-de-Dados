-- Script para inserir dados de exemplo no sistema de viagem
-- Execute após criar as tabelas

-- Inserir usuários de exemplo
INSERT INTO usuario (nome, email, telefone) VALUES
('João Silva', 'joao.silva@email.com', '(11) 99999-1111'),
('Maria Santos', 'maria.santos@email.com', '(11) 99999-2222'),
('Pedro Oliveira', 'pedro.oliveira@email.com', '(11) 99999-3333'),
('Ana Costa', 'ana.costa@email.com', '(11) 99999-4444');

-- Inserir reservas de exemplo
INSERT INTO reserva (usuario_id, destino_id, data_viagem, data_retorno, num_pessoas, valor_total, status, observacoes) VALUES
(1, 1, '2025-02-15', '2025-02-20', 2, 1600.00, 'confirmada', 'Primeira viagem de casal'),
(2, 2, '2025-03-10', '2025-03-15', 1, 1200.00, 'pendente', 'Viagem de aniversário'),
(3, 3, '2025-04-05', '2025-04-08', 3, 1500.00, 'confirmada', 'Viagem em família'),
(4, 1, '2025-05-20', '2025-05-25', 2, 1600.00, 'pendente', 'Férias de verão');

-- Inserir contatos de exemplo
INSERT INTO contato (nome, email, mensagem) VALUES
('Carlos Ferreira', 'carlos.ferreira@email.com', 'Gostaria de informações sobre pacotes para o Rio de Janeiro.'),
('Lucia Mendes', 'lucia.mendes@email.com', 'Preciso de ajuda para planejar uma viagem de 15 dias pelo Brasil.'),
('Roberto Alves', 'roberto.alves@email.com', 'Qual o melhor período para viajar para Salvador?');

-- Consultas de verificação
SELECT 'Destinos inseridos:' as info, COUNT(*) as total FROM destino;
SELECT 'Usuários inseridos:' as info, COUNT(*) as total FROM usuario;
SELECT 'Reservas inseridas:' as info, COUNT(*) as total FROM reserva;
SELECT 'Contatos inseridos:' as info, COUNT(*) as total FROM contato;
