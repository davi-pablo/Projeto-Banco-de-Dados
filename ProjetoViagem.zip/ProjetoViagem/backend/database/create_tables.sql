-- Script de criação das tabelas para o sistema de viagem no MySQL
-- Para usar no Railway MySQL

-- Criar database (se necessário)
-- CREATE DATABASE IF NOT EXISTS universi_tour;
-- USE universi_tour;

-- Tabela de Destinos
CREATE TABLE IF NOT EXISTS destino (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT NOT NULL,
    imagem VARCHAR(200) NOT NULL,
    distancia VARCHAR(50) NOT NULL,
    preco VARCHAR(20) NOT NULL,
    preco_numerico DECIMAL(10,2) NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Reservas
CREATE TABLE IF NOT EXISTS reserva (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    destino_id INT NOT NULL,
    data_viagem DATE NOT NULL,
    data_retorno DATE NOT NULL,
    num_pessoas INT NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pendente',
    observacoes TEXT,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE CASCADE,
    FOREIGN KEY (destino_id) REFERENCES destino(id) ON DELETE CASCADE
);

-- Tabela de Contatos
CREATE TABLE IF NOT EXISTS contato (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL,
    mensagem TEXT NOT NULL,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    respondido BOOLEAN DEFAULT FALSE
);

-- Inserir dados iniciais dos destinos
INSERT INTO destino (nome, descricao, imagem, distancia, preco, preco_numerico) VALUES
('Rio de Janeiro', 'A cidade carioca, famosa por suas praias e seus pontos turísticos.', 'Imagens/rio.jpg', '100-500', 'medio', 800.00),
('Salvador', 'A cidade calorosa, um lugar de tradição e cultura.', 'Imagens/salvador.jpg', '500-1000', 'alto', 1200.00),
('Recife', 'A cidade maravilhosa, com praias paradisíacas e cultura vibrante.', 'Imagens/recife.jpg', '0-100', 'baixo', 500.00);

-- Índices para melhorar performance
CREATE INDEX IF NOT EXISTS idx_destino_ativo ON destino(ativo);
CREATE INDEX IF NOT EXISTS idx_destino_preco ON destino(preco);
CREATE INDEX IF NOT EXISTS idx_destino_distancia ON destino(distancia);
CREATE INDEX IF NOT EXISTS idx_usuario_email ON usuario(email);
CREATE INDEX IF NOT EXISTS idx_reserva_usuario ON reserva(usuario_id);
CREATE INDEX IF NOT EXISTS idx_reserva_destino ON reserva(destino_id);
CREATE INDEX IF NOT EXISTS idx_reserva_status ON reserva(status);
CREATE INDEX IF NOT EXISTS idx_contato_respondido ON contato(respondido);
CREATE INDEX IF NOT EXISTS idx_contato_data_envio ON contato(data_envio);
